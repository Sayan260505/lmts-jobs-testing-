// Main Application Controller
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span>${type === 'success' ? '✓' : (type === 'error' ? '⚠' : 'ℹ')}</span>
    <span>${message}</span>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

const App = {
  currentTab: 'jobs',

  init() {
    this.initTheme();
    this.bindNavigation();
    this.bindModals();
    this.updateStats();

    // Initialize modules
    JobsModule.init();
    PrepModule.init();
    CompaniesModule.init();
    DSAModule.init();
    ApplicationsTrackerModule.init();
  },

  initTheme() {
    const savedTheme = localStorage.getItem('hireprep_theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
    this.updateThemeButton(savedTheme);
    const themeBtn = document.getElementById('theme-toggle-btn');
    if (themeBtn) {
      themeBtn.addEventListener('click', () => this.toggleTheme());
    }
  },

  updateThemeButton(theme) {
    const iconEl = document.getElementById('theme-icon');
    const textEl = document.getElementById('theme-text');
    const themeBtn = document.getElementById('theme-toggle-btn');
    if (theme === 'dark') {
      if (iconEl) iconEl.innerText = '🌙';
      if (textEl) textEl.innerText = 'Dark Mode';
      if (themeBtn) themeBtn.title = 'Current: Dark Mode. Click to switch to Light Mode.';
    } else {
      if (iconEl) iconEl.innerText = '☀️';
      if (textEl) textEl.innerText = 'Light Mode';
      if (themeBtn) themeBtn.title = 'Current: Light Mode. Click to switch to Dark Mode.';
    }
  },

  toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('hireprep_theme', next);
    this.updateThemeButton(next);
    showToast(`Switched to ${next === 'dark' ? 'Dark' : 'Light'} Mode`, 'info');
  },

  bindNavigation() {
    document.querySelectorAll('.nav-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.tab;
        this.switchTab(target);
      });
    });
  },

  switchTab(tabName) {
    this.currentTab = tabName;

    // Update active navbar button
    document.querySelectorAll('.nav-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tabName);
    });

    // Update active tab pane
    document.querySelectorAll('.tab-pane').forEach(pane => {
      if (pane.id === `tab-${tabName}`) {
        pane.style.display = 'block';
        pane.classList.add('fade-in');
      } else {
        pane.style.display = 'none';
      }
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Refresh active tab data if needed
    if (tabName === 'jobs') JobsModule.loadJobs();
    else if (tabName === 'prep') PrepModule.loadTopics();
    else if (tabName === 'companies') CompaniesModule.loadCompanies();
    else if (tabName === 'dsa') DSAModule.loadSheet();
    else if (tabName === 'applications') ApplicationsTrackerModule.loadApplications();

    this.updateStats();
  },

  bindModals() {
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          overlay.classList.remove('active');
        }
      });
    });

    document.querySelectorAll('.close-modal-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const modal = btn.closest('.modal-overlay');
        if (modal) modal.classList.remove('active');
      });
    });
  },

  async updateStats() {
    try {
      const res = await fetch('/api/dashboard/stats');
      const stats = await res.json();

      const jobsStat = document.getElementById('stat-jobs-total');
      const dsaStat = document.getElementById('stat-dsa-solved');
      const prepStat = document.getElementById('stat-prep-topics');
      const appStat = document.getElementById('stat-applications-count');

      if (jobsStat) jobsStat.innerText = `${stats.total_jobs} Active`;
      if (dsaStat) dsaStat.innerText = `${stats.solved_dsa} / ${stats.total_dsa}`;
      if (prepStat) prepStat.innerText = `${stats.total_prep_topics} Modules`;
      if (appStat) appStat.innerText = `${stats.total_applications} Tracked`;

      // Update badge in navbar
      const navJobsBadge = document.getElementById('nav-jobs-badge');
      const navAppsBadge = document.getElementById('nav-apps-badge');
      if (navJobsBadge) navJobsBadge.innerText = stats.total_jobs;
      if (navAppsBadge) navAppsBadge.innerText = stats.total_applications;
    } catch (err) {
      console.error(err);
    }
  }
};

window.addEventListener('DOMContentLoaded', () => {
  App.init();
});
