﻿// Jobs Module
const JobsModule = {
  jobs: [],
  currentJob: null,

  async init() {
    this.bindEvents();
    await this.loadJobs();
  },

  bindEvents() {
    const searchInput = document.getElementById('job-search-input');
    const typeSelect = document.getElementById('job-type-filter');
    const expSelect = document.getElementById('job-exp-filter');

    if (searchInput) {
      searchInput.addEventListener('input', debounce(() => this.loadJobs(), 300));
    }
    if (typeSelect) {
      typeSelect.addEventListener('change', () => this.loadJobs());
    }
    if (expSelect) {
      expSelect.addEventListener('change', () => this.loadJobs());
    }

    const applyForm = document.getElementById('quick-apply-form');
    if (applyForm) {
      applyForm.addEventListener('submit', (e) => this.handleApplySubmit(e));
    }
  },

  async loadJobs() {
    const search = document.getElementById('job-search-input')?.value || '';
    const type = document.getElementById('job-type-filter')?.value || '';
    const exp = document.getElementById('job-exp-filter')?.value || '';

    const container = document.getElementById('jobs-grid');
    if (!container) return;
    container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-secondary);">Loading job listings...</div>';

    try {
      const res = await fetch(`/api/jobs?search=${encodeURIComponent(search)}&type=${encodeURIComponent(type)}&experience=${encodeURIComponent(exp)}`);
      this.jobs = await res.json();
      this.renderJobs();
    } catch (err) {
      console.error('Failed to load jobs', err);
      container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--accent-rose);">Error loading jobs. Please check server.</div>';
    }
  },

  renderJobs() {
    const container = document.getElementById('jobs-grid');
    const countEl = document.getElementById('jobs-count-badge');
    if (countEl) countEl.innerText = `${this.jobs.length} Openings`;

    if (!this.jobs.length) {
      container.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 60px 20px; background: var(--bg-card); border-radius: var(--radius); border: 1px dashed var(--border-color);">
          <div style="font-size: 36px; margin-bottom: 12px;">🔍</div>
          <h3 style="font-size: 18px; margin-bottom: 8px;">No jobs found matching your criteria</h3>
          <p style="color: var(--text-secondary); font-size: 14px;">Try clearing your filters or searching for different keywords.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = this.jobs.map(job => {
      const skillsArray = job.skills.split(',').map(s => s.trim());
      const isApplied = job.application_status !== null;
      const appliedBadge = isApplied 
        ? `<span class="badge badge-green">✓ Applied (${job.application_status})</span>`
        : '';

      return `
        <div class="card job-card fade-in" style="display: flex; flex-direction: column; justify-content: space-between;">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 14px;">
              <div style="display: flex; gap: 12px; align-items: center;">
                <div style="width: 46px; height: 46px; border-radius: 10px; background: var(--bg-primary); border: 1px solid var(--border-color); display: flex; align-items: center; justify-content: center; overflow: hidden; padding: 6px;">
                  <img src="${job.logo_url}" alt="${job.company}" style="max-width: 100%; max-height: 100%; object-fit: contain;" onerror="this.src='https://via.placeholder.com/46?text=${job.company[0]}'">
                </div>
                <div>
                  <h3 style="font-size: 16px; font-weight: 700; line-height: 1.3; margin-bottom: 2px;">${job.title}</h3>
                  <div style="font-size: 13px; color: var(--text-secondary); font-weight: 600;">${job.company}</div>
                </div>
              </div>
              <button onclick="JobsModule.toggleSaveJob(${job.id}, this)" class="btn-outline btn-sm" style="padding: 6px 10px; border-radius: 8px;" title="Save Job">
                ${job.is_saved ? '⭐ Saved' : '☆ Save'}
              </button>
            </div>

            <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 14px;">
              <span class="badge badge-blue">💼 ${job.job_type}</span>
              <span class="badge badge-purple">🎓 ${job.experience_level}</span>
              <span class="badge badge-green">💰 ${job.salary_range}</span>
              <span class="badge badge-gray">📍 ${job.location}</span>
              ${appliedBadge}
            </div>

            <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 16px; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
              ${job.description}
            </p>

            <div style="display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 18px;">
              ${skillsArray.slice(0, 4).map(skill => `<span style="font-size: 11px; background: var(--bg-primary); border: 1px solid var(--border-color); padding: 3px 8px; border-radius: 6px; color: var(--text-secondary); font-weight: 500;">${skill}</span>`).join('')}
              ${skillsArray.length > 4 ? `<span style="font-size: 11px; padding: 3px 6px; color: var(--text-muted);">+${skillsArray.length - 4} more</span>` : ''}
            </div>
          </div>

          <div style="border-top: 1px solid var(--border-color); padding-top: 14px; display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 11px; color: var(--text-muted);">Deadline: ${job.deadline || 'Rolling'}</span>
            <div style="display: flex; gap: 8px;">
              <button onclick="JobsModule.openJobDetail(${job.id})" class="btn btn-secondary btn-sm">Details</button>
              ${isApplied 
                ? `<button class="btn btn-sm btn-secondary" disabled style="opacity: 0.7;">Applied</button>` 
                : `<button onclick="JobsModule.openQuickApply(${job.id})" class="btn btn-primary btn-sm">Quick Apply</button>`
              }
            </div>
          </div>
        </div>
      `;
    }).join('');
  },

  async toggleSaveJob(jobId, btn) {
    try {
      const res = await fetch('/api/jobs/toggle-save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ job_id: jobId })
      });
      const data = await res.json();
      if (data.success) {
        btn.innerHTML = data.is_saved ? '⭐ Saved' : '☆ Save';
        showToast(data.is_saved ? 'Job added to bookmarks!' : 'Job removed from bookmarks.', 'success');
        const job = this.jobs.find(j => j.id === jobId);
        if (job) job.is_saved = data.is_saved ? 1 : 0;
      }
    } catch (err) {
      console.error(err);
      showToast('Failed to toggle save job', 'error');
    }
  },

  async openJobDetail(jobId) {
    try {
      const res = await fetch(`/api/jobs/${jobId}`);
      const job = await res.json();
      this.currentJob = job;

      const modal = document.getElementById('job-detail-modal');
      const body = document.getElementById('job-detail-body');
      const title = document.getElementById('job-detail-title');

      title.innerText = job.title;
      body.innerHTML = `
        <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--border-color);">
          <img src="${job.logo_url}" style="width: 54px; height: 54px; object-fit: contain; background: var(--bg-primary); padding: 6px; border-radius: 12px; border: 1px solid var(--border-color);" onerror="this.src='https://via.placeholder.com/54'">
          <div>
            <h2 style="font-size: 18px; font-weight: 700;">${job.company}</h2>
            <div style="font-size: 13px; color: var(--text-secondary);">📍 ${job.location} • 💼 ${job.job_type}</div>
            <div style="font-size: 14px; color: var(--accent-emerald); font-weight: 700; margin-top: 4px;">💰 ${job.salary_range}</div>
          </div>
        </div>

        <div style="margin-bottom: 20px;">
          <h4 style="font-size: 14px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); margin-bottom: 8px;">Role Description</h4>
          <p style="font-size: 14px; line-height: 1.6; color: var(--text-secondary);">${job.description}</p>
        </div>

        <div style="margin-bottom: 20px;">
          <h4 style="font-size: 14px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); margin-bottom: 8px;">Candidate Requirements & Eligibility</h4>
          <p style="font-size: 14px; line-height: 1.6; color: var(--text-secondary);">${job.requirements}</p>
        </div>

        <div style="margin-bottom: 20px;">
          <h4 style="font-size: 14px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); margin-bottom: 8px;">Required Skills & Tech Stack</h4>
          <div style="display: flex; flex-wrap: wrap; gap: 8px;">
            ${job.skills.split(',').map(s => `<span class="badge badge-blue">${s.trim()}</span>`).join('')}
          </div>
        </div>

        <div style="background: var(--bg-primary); padding: 16px; border-radius: 10px; border: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
          <div>
            <div style="font-size: 12px; color: var(--text-muted);">Application Deadline</div>
            <div style="font-weight: 600; font-size: 14px;">${job.deadline || 'Rolling Applications'}</div>
          </div>
          <button onclick="JobsModule.openQuickApply(${job.id})" class="btn btn-primary">
            ${job.application_status ? '✓ Applied' : 'Quick Apply Now'}
          </button>
        </div>
      `;

      modal.classList.add('active');
    } catch (err) {
      console.error(err);
      showToast('Could not load job details', 'error');
    }
  },

  openQuickApply(jobId) {
    const job = this.jobs.find(j => j.id === jobId) || this.currentJob;
    if (!job) return;

    document.getElementById('job-detail-modal')?.classList.remove('active');

    const modal = document.getElementById('quick-apply-modal');
    document.getElementById('apply-job-id').value = job.id;
    document.getElementById('apply-modal-title').innerText = `Apply to ${job.company}`;
    document.getElementById('apply-modal-subtitle').innerText = `Position: ${job.title} (${job.location})`;

    modal.classList.add('active');
  },

  async handleApplySubmit(e) {
    e.preventDefault();
    const jobId = document.getElementById('apply-job-id').value;
    const name = document.getElementById('apply-candidate-name').value;
    const email = document.getElementById('apply-candidate-email').value;
    const portfolio = document.getElementById('apply-candidate-portfolio').value;
    const resumeName = document.getElementById('apply-resume-file').value || 'Resume_SoftwareEngineer.pdf';
    const notes = document.getElementById('apply-notes').value;

    const submitBtn = e.target.querySelector('button[type="submit"]');
    submitBtn.innerText = 'Submitting...';
    submitBtn.disabled = true;

    try {
      const res = await fetch('/api/jobs/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          job_id: jobId,
          name: name,
          email: email,
          portfolio: portfolio,
          resume_name: resumeName,
          notes: notes
        })
      });

      const data = await res.json();
      if (res.ok) {
        showToast('Application submitted successfully! Tracking enabled.', 'success');
        document.getElementById('quick-apply-modal').classList.remove('active');
        e.target.reset();
        await this.loadJobs();
        await ApplicationsTrackerModule.loadApplications();
        if (window.App) window.App.updateStats();
      } else {
        showToast(data.error || 'Failed to submit application', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Submission error. Please retry.', 'error');
    } finally {
      submitBtn.innerText = 'Submit Application';
      submitBtn.disabled = false;
    }
  }
};

// Applications & Tracking Board Module
const ApplicationsTrackerModule = {
  applications: [],

  async init() {
    await this.loadApplications();
  },

  async loadApplications() {
    const container = document.getElementById('applications-list');
    if (!container) return;

    try {
      const res = await fetch('/api/applications');
      this.applications = await res.json();
      this.render();
    } catch (err) {
      console.error(err);
    }
  },

  render() {
    const container = document.getElementById('applications-list');
    if (!container) return;

    if (!this.applications.length) {
      container.innerHTML = `
        <div style="text-align: center; padding: 60px 20px; background: var(--bg-card); border-radius: var(--radius); border: 1px dashed var(--border-color);">
          <div style="font-size: 38px; margin-bottom: 12px;">📝</div>
          <h3 style="font-size: 18px; margin-bottom: 8px;">No Applications Yet</h3>
          <p style="color: var(--text-secondary); font-size: 14px; margin-bottom: 18px;">Browse the Job Portal and use 'Quick Apply' to start tracking your interviews.</p>
          <button onclick="App.switchTab('jobs')" class="btn btn-primary">Browse Job Openings</button>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div style="display: grid; gap: 14px;">
        ${this.applications.map(app => {
          const statusColors = {
            'Applied': 'badge-blue',
            'In Review': 'badge-purple',
            'Interviewing': 'badge-amber',
            'Offered': 'badge-green',
            'Rejected': 'badge-rose'
          };
          const badgeClass = statusColors[app.status] || 'badge-gray';

          return `
            <div class="card fade-in" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
              <div style="display: flex; gap: 14px; align-items: center;">
                <img src="${app.logo_url}" style="width: 44px; height: 44px; object-fit: contain; background: var(--bg-primary); padding: 5px; border-radius: 10px; border: 1px solid var(--border-color);" onerror="this.src='https://via.placeholder.com/44'">
                <div>
                  <h4 style="font-size: 16px; font-weight: 700;">${app.title}</h4>
                  <div style="font-size: 13px; color: var(--text-secondary);">${app.company} • 📍 ${app.location}</div>
                  <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Candidate: ${app.candidate_name} (${app.candidate_email}) • Applied on: ${app.applied_at.split(' ')[0]}</div>
                </div>
              </div>

              <div style="display: flex; align-items: center; gap: 12px;">
                <span class="badge ${badgeClass}">${app.status}</span>
                <select onchange="ApplicationsTrackerModule.updateStatus(${app.id}, this.value)" class="select-filter" style="padding: 6px 10px; font-size: 13px;">
                  <option value="Applied" ${app.status === 'Applied' ? 'selected' : ''}>Applied</option>
                  <option value="In Review" ${app.status === 'In Review' ? 'selected' : ''}>In Review</option>
                  <option value="Interviewing" ${app.status === 'Interviewing' ? 'selected' : ''}>Interviewing</option>
                  <option value="Offered" ${app.status === 'Offered' ? 'selected' : ''}>Offered 🎉</option>
                  <option value="Rejected" ${app.status === 'Rejected' ? 'selected' : ''}>Rejected</option>
                </select>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  },

  async updateStatus(appId, newStatus) {
    try {
      const res = await fetch(`/api/applications/${appId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        showToast(`Status updated to ${newStatus}`, 'success');
        await this.loadApplications();
        if (window.App) window.App.updateStats();
      }
    } catch (err) {
      console.error(err);
      showToast('Failed to update status', 'error');
    }
  }
};
