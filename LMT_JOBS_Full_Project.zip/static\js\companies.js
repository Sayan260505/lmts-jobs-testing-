﻿// Companies Module
const CompaniesModule = {
  companies: [],
  selectedCompanyId: null,

  async init() {
    this.bindEvents();
    await this.loadCompanies();
  },

  bindEvents() {
    document.querySelectorAll('.company-cat-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.company-cat-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.loadCompanies(btn.dataset.category);
      });
    });

    const eligForm = document.getElementById('eligibility-checker-form');
    if (eligForm) {
      eligForm.addEventListener('submit', (e) => this.checkEligibility(e));
    }
  },

  async loadCompanies(category = 'All') {
    const listContainer = document.getElementById('companies-selector-list');
    if (!listContainer) return;

    try {
      const res = await fetch(`/api/companies?category=${encodeURIComponent(category)}`);
      this.companies = await res.json();
      this.renderCompanyList();

      if (this.companies.length && !this.selectedCompanyId) {
        this.selectCompany(this.companies[0].id);
      } else if (this.companies.length) {
        const currentStillValid = this.companies.some(c => c.id === this.selectedCompanyId);
        this.selectCompany(currentStillValid ? this.selectedCompanyId : this.companies[0].id);
      }
    } catch (err) {
      console.error(err);
    }
  },

  renderCompanyList() {
    const container = document.getElementById('companies-selector-list');
    if (!container) return;

    container.innerHTML = this.companies.map(c => `
      <div onclick="CompaniesModule.selectCompany(${c.id})" 
           class="company-pill-item ${c.id === this.selectedCompanyId ? 'active' : ''}" 
           style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: 10px; border: 1px solid var(--border-color); background: var(--bg-card); cursor: pointer; transition: all 0.2s;">
        <img src="${c.logo_url}" style="width: 32px; height: 32px; object-fit: contain; background: var(--bg-primary); padding: 4px; border-radius: 8px; border: 1px solid var(--border-color);" onerror="this.src='https://via.placeholder.com/32'">
        <div style="flex: 1;">
          <div style="font-weight: 700; font-size: 14px; color: var(--text-primary);">${c.name}</div>
          <div style="font-size: 11px; color: var(--text-muted);">${c.badge}</div>
        </div>
        <span class="badge ${c.category === 'Product' ? 'badge-blue' : 'badge-purple'}" style="font-size: 10px;">${c.category}</span>
      </div>
    `).join('');
  },

  async selectCompany(companyId) {
    this.selectedCompanyId = companyId;
    this.renderCompanyList();

    const detailContainer = document.getElementById('company-detail-view');
    if (!detailContainer) return;

    detailContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-secondary);">Loading company hiring blueprint...</div>';

    try {
      const res = await fetch(`/api/companies/${companyId}`);
      const comp = await res.json();
      this.renderCompanyDetail(comp);
    } catch (err) {
      console.error(err);
      detailContainer.innerHTML = '<div style="color: var(--accent-rose); text-align: center; padding: 40px;">Error loading company guide.</div>';
    }
  },

  renderCompanyDetail(comp) {
    const detailContainer = document.getElementById('company-detail-view');
    if (!detailContainer) return;

    // Set hidden company ID in eligibility checker
    const hiddenId = document.getElementById('elig-company-id');
    if (hiddenId) hiddenId.value = comp.id;
    const companyTitleEl = document.getElementById('elig-company-name');
    if (companyTitleEl) companyTitleEl.innerText = comp.name;

    detailContainer.innerHTML = `
      <div class="card fade-in" style="margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 16px; margin-bottom: 20px; padding-bottom: 18px; border-bottom: 1px solid var(--border-color);">
          <div style="display: flex; gap: 16px; align-items: center;">
            <img src="${comp.logo_url}" style="width: 58px; height: 58px; object-fit: contain; background: var(--bg-primary); padding: 8px; border-radius: 12px; border: 1px solid var(--border-color);" onerror="this.src='https://via.placeholder.com/58'">
            <div>
              <div style="display: flex; align-items: center; gap: 10px;">
                <h2 style="font-size: 22px; font-weight: 800; color: var(--text-primary);">${comp.name}</h2>
                <span class="badge badge-purple">${comp.badge}</span>
                <span class="badge ${comp.category === 'Product' ? 'badge-blue' : 'badge-green'}">${comp.category}</span>
              </div>
              <p style="font-size: 14px; color: var(--text-secondary); margin-top: 4px;">${comp.overview}</p>
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase; font-weight: 700;">CTC / Package Range</div>
            <div style="font-size: 18px; font-weight: 800; color: var(--accent-emerald);">${comp.package_info}</div>
          </div>
        </div>

        <!-- Eligibility Criteria Summary -->
        <div style="background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 10px; padding: 16px; margin-bottom: 24px;">
          <h4 style="font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #60a5fa; margin-bottom: 12px;">📋 Official Eligibility Guidelines</h4>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; font-size: 13px;">
            <div><strong style="color: var(--text-primary);">Minimum Academic Score:</strong> <div style="color: var(--text-secondary);">${comp.eligibility_criteria.min_cgpa}</div></div>
            <div><strong style="color: var(--text-primary);">Eligible Branches:</strong> <div style="color: var(--text-secondary);">${comp.eligibility_criteria.eligible_branches.join(', ')}</div></div>
            <div><strong style="color: var(--text-primary);">Backlog Policy:</strong> <div style="color: var(--text-secondary);">${comp.eligibility_criteria.backlog_policy}</div></div>
            <div><strong style="color: var(--text-primary);">Gap Year Allowed:</strong> <div style="color: var(--text-secondary);">${comp.eligibility_criteria.gap_year_allowed}</div></div>
          </div>
        </div>

        <!-- Selection Rounds Progression Timeline -->
        <div style="margin-bottom: 28px;">
          <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
            <span>🚀 Selection Rounds Progression</span>
          </h3>
          <div style="display: grid; gap: 12px;">
            ${comp.rounds_breakdown.map((r, i) => `
              <div style="display: flex; gap: 14px; background: var(--bg-primary); border: 1px solid var(--border-color); padding: 14px 18px; border-radius: 10px; align-items: flex-start;">
                <div style="width: 32px; height: 32px; border-radius: 50%; background: var(--accent-blue); color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 13px; flex-shrink: 0;">
                  ${r.round}
                </div>
                <div>
                  <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 4px;">
                    <h4 style="font-size: 15px; font-weight: 700; color: var(--text-primary);">${r.name}</h4>
                    <span class="badge badge-gray" style="font-size: 11px;">${r.type}</span>
                  </div>
                  <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.5;">${r.desc}</p>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Exam Pattern & Syllabus Breakdown -->
        <div style="margin-bottom: 28px;">
          <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 14px;">📝 Online Assessment & Exam Pattern</h3>
          <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; font-size: 13px; text-align: left;">
              <thead>
                <tr style="background: var(--bg-primary); border-bottom: 2px solid var(--border-color); color: var(--text-primary);">
                  <th style="padding: 10px 14px;">Section Name</th>
                  <th style="padding: 10px 14px;">Duration</th>
                  <th style="padding: 10px 14px;">Questions / Format</th>
                  <th style="padding: 10px 14px;">Details</th>
                </tr>
              </thead>
              <tbody>
                ${comp.exam_pattern.map(p => `
                  <tr style="border-bottom: 1px solid var(--border-color);">
                    <td style="padding: 12px 14px; font-weight: 600; color: var(--text-primary);">${p.section}</td>
                    <td style="padding: 12px 14px; color: #fbbf24;">${p.duration}</td>
                    <td style="padding: 12px 14px; color: var(--text-secondary);">${p.questions}</td>
                    <td style="padding: 12px 14px; color: var(--text-muted); font-size: 12px;">${p.marking || p.platform || 'Standard evaluation'}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Topics & Syllabus Grid -->
        <div style="margin-bottom: 28px;">
          <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 14px;">🎯 Key Syllabus Focus Areas</h3>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 14px;">
            ${Object.entries(comp.syllabus).map(([category, items]) => `
              <div style="background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 8px; padding: 14px;">
                <h4 style="font-size: 13px; font-weight: 700; color: #60a5fa; margin-bottom: 8px; text-transform: uppercase;">${category.replace('_', ' ')}</h4>
                <div style="display: flex; flex-wrap: wrap; gap: 6px;">
                  ${items.map(it => `<span class="badge badge-blue" style="font-size: 11px;">${it}</span>`).join('')}
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Recent Interview Questions -->
        <div style="margin-bottom: 28px;">
          <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 14px;">💬 Frequently Asked Questions in Past Drives</h3>
          <div style="display: grid; gap: 10px;">
            ${comp.past_questions.map(q => `
              <div style="background: var(--bg-primary); border-left: 3px solid var(--accent-purple); padding: 12px 16px; border-radius: 6px; font-size: 13px; color: var(--text-secondary);">
                "${q}"
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Pro Preparation Tips -->
        <div>
          <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 14px; color: #34d399;">🌟 Placed Candidates & Interviewer Tips</h3>
          <ul style="padding-left: 20px; font-size: 13px; color: var(--text-secondary); line-height: 1.6;">
            ${comp.pro_tips.map(t => `<li style="margin-bottom: 6px;">${t}</li>`).join('')}
          </ul>
        </div>
      </div>
    `;
  },

  async checkEligibility(e) {
    e.preventDefault();
    const companyId = this.selectedCompanyId;
    const cgpa = document.getElementById('elig-user-cgpa').value;
    const branch = document.getElementById('elig-user-branch').value;
    const backlogs = document.getElementById('elig-user-backlogs').value;
    const resultBox = document.getElementById('eligibility-result-box');

    if (!resultBox) return;
    resultBox.style.display = 'block';
    resultBox.innerHTML = '<div style="text-align: center; color: var(--text-secondary); padding: 12px;">Evaluating requirements against criteria...</div>';

    try {
      const res = await fetch('/api/companies/check-eligibility', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          company_id: companyId,
          cgpa: cgpa,
          branch: branch,
          backlogs: backlogs
        })
      });
      const data = await res.json();

      const isEligible = data.is_eligible;
      resultBox.innerHTML = `
        <div style="padding: 16px; border-radius: 10px; border: 1px solid ${isEligible ? 'var(--accent-emerald)' : 'var(--accent-rose)'}; background: ${isEligible ? 'rgba(16, 185, 129, 0.1)' : 'rgba(244, 63, 94, 0.1)'};">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
            <span style="font-size: 20px;">${isEligible ? '✅' : '⚠️'}</span>
            <strong style="font-size: 15px; color: ${isEligible ? 'var(--accent-emerald)' : 'var(--accent-rose)'};">
              ${isEligible ? `Eligible for ${data.company} Recruitment Drives!` : `Not currently eligible for ${data.company}`}
            </strong>
          </div>
          <ul style="font-size: 13px; color: var(--text-secondary); padding-left: 20px; line-height: 1.5;">
            ${data.details.map(d => `<li>${d}</li>`).join('')}
          </ul>
        </div>
      `;
    } catch (err) {
      console.error(err);
      resultBox.innerHTML = '<div style="color: var(--accent-rose);">Failed to calculate eligibility.</div>';
    }
  }
};
