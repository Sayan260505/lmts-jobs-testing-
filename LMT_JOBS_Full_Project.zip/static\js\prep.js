﻿// Preparation Hub Module
const PrepModule = {
  topics: [],
  currentCategory: 'All',
  mode: 'notes', // 'notes' or 'quiz'
  quizQuestions: [],
  quizAnswers: {},
  quizTimerInterval: null,
  quizTimeSeconds: 600, // 10 minutes

  async init() {
    this.bindEvents();
    await this.loadTopics();
  },

  bindEvents() {
    document.querySelectorAll('.prep-cat-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.prep-cat-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.currentCategory = btn.dataset.category;
        if (this.mode === 'notes') {
          this.loadTopics();
        } else {
          this.startQuiz();
        }
      });
    });

    const modeNotesBtn = document.getElementById('mode-notes-btn');
    const modeQuizBtn = document.getElementById('mode-quiz-btn');

    if (modeNotesBtn && modeQuizBtn) {
      modeNotesBtn.addEventListener('click', () => {
        this.mode = 'notes';
        modeNotesBtn.classList.add('active');
        modeQuizBtn.classList.remove('active');
        document.getElementById('prep-notes-container').style.display = 'block';
        document.getElementById('prep-quiz-container').style.display = 'none';
        this.loadTopics();
      });

      modeQuizBtn.addEventListener('click', () => {
        this.mode = 'quiz';
        modeQuizBtn.classList.add('active');
        modeNotesBtn.classList.remove('active');
        document.getElementById('prep-notes-container').style.display = 'none';
        document.getElementById('prep-quiz-container').style.display = 'block';
        this.startQuiz();
      });
    }
  },

  async loadTopics() {
    const container = document.getElementById('prep-topics-grid');
    if (!container) return;
    container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-secondary);">Loading notes and cheat sheets...</div>';

    try {
      const res = await fetch(`/api/prep/topics?category=${encodeURIComponent(this.currentCategory)}`);
      this.topics = await res.json();
      this.renderTopics();
    } catch (err) {
      console.error(err);
      container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--accent-rose);">Failed to load preparation topics.</div>';
    }
  },

  renderTopics() {
    const container = document.getElementById('prep-topics-grid');
    if (!container) return;

    if (!this.topics.length) {
      container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-secondary);">No topics available in this category.</div>';
      return;
    }

    container.innerHTML = this.topics.map(topic => {
      const keyPoints = Array.isArray(topic.key_formulas_or_points) ? topic.key_formulas_or_points : [];

      return `
        <div class="card fade-in" style="margin-bottom: 24px;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
            <div>
              <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;">
                <span class="badge badge-purple">${topic.category}</span>
                <span class="badge badge-blue">${topic.subcategory}</span>
              </div>
              <h3 style="font-size: 19px; font-weight: 700; color: var(--text-primary);">${topic.title}</h3>
            </div>
            <button onclick="PrepModule.toggleContent(${topic.id}, this)" class="btn btn-secondary btn-sm">
              Read Notes ▼
            </button>
          </div>

          <p style="font-size: 14px; color: var(--text-secondary); margin-bottom: 16px;">
            ${topic.summary}
          </p>

          ${keyPoints.length ? `
            <div style="background: rgba(59, 130, 246, 0.08); border-left: 3px solid var(--accent-blue); padding: 12px 16px; border-radius: 6px; margin-bottom: 16px;">
              <div style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: #60a5fa; margin-bottom: 6px;">💡 Key Formulas & Interview Points</div>
              <ul style="padding-left: 20px; font-size: 13px; color: var(--text-secondary); line-height: 1.6;">
                ${keyPoints.map(kp => `<li>${kp}</li>`).join('')}
              </ul>
            </div>
          ` : ''}

          <div id="topic-content-${topic.id}" style="display: none; border-top: 1px solid var(--border-color); padding-top: 18px; margin-top: 14px;" class="fade-in">
            <div style="text-align: center; padding: 12px; color: var(--text-muted);">Fetching detailed markdown...</div>
          </div>
        </div>
      `;
    }).join('');
  },

  async toggleContent(topicId, btn) {
    const contentDiv = document.getElementById(`topic-content-${topicId}`);
    if (!contentDiv) return;

    if (contentDiv.style.display === 'block') {
      contentDiv.style.display = 'none';
      btn.innerText = 'Read Notes ▼';
      return;
    }

    btn.innerText = 'Hide Notes ▲';
    contentDiv.style.display = 'block';

    try {
      const res = await fetch(`/api/prep/topics/${topicId}`);
      const data = await res.json();
      contentDiv.innerHTML = `
        <div style="font-size: 14px; line-height: 1.7; color: var(--text-secondary); white-space: pre-wrap; font-family: inherit;">
          ${this.formatMarkdown(data.content_markdown)}
        </div>
      `;
    } catch (err) {
      contentDiv.innerHTML = '<div style="color: var(--accent-rose);">Failed to load content.</div>';
    }
  },

  formatMarkdown(md) {
    if (!md) return '';
    let html = md
      .replace(/^### (.*$)/gim, '<h4 style="font-size: 16px; font-weight: 700; color: var(--text-primary); margin: 16px 0 8px;">$1</h4>')
      .replace(/^#### (.*$)/gim, '<h5 style="font-size: 14px; font-weight: 700; color: #60a5fa; margin: 12px 0 6px;">$1</h5>')
      .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/gim, '<em>$1</em>')
      .replace(/`([^`]+)`/gim, '<code style="background: var(--bg-primary); padding: 2px 6px; border-radius: 4px; font-size: 12px; border: 1px solid var(--border-color); color: #38bdf8;">$1</code>');
    return html;
  },

  // Interactive Quiz Engine
  async startQuiz() {
    const container = document.getElementById('quiz-questions-view');
    const resultView = document.getElementById('quiz-results-view');
    if (!container) return;

    container.style.display = 'block';
    if (resultView) resultView.style.display = 'none';

    container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-secondary);">Preparing your interactive test...</div>';
    this.quizAnswers = {};

    try {
      const res = await fetch(`/api/prep/quiz?category=${encodeURIComponent(this.currentCategory)}`);
      this.quizQuestions = await res.json();
      this.renderQuiz();
      this.startTimer();
    } catch (err) {
      console.error(err);
      container.innerHTML = '<div style="color: var(--accent-rose); text-align: center; padding: 40px;">Failed to load quiz questions.</div>';
    }
  },

  startTimer() {
    if (this.quizTimerInterval) clearInterval(this.quizTimerInterval);
    this.quizTimeSeconds = 600;
    const timerEl = document.getElementById('quiz-timer');

    this.quizTimerInterval = setInterval(() => {
      this.quizTimeSeconds--;
      if (this.quizTimeSeconds <= 0) {
        clearInterval(this.quizTimerInterval);
        this.submitQuiz();
        return;
      }
      const mins = Math.floor(this.quizTimeSeconds / 60);
      const secs = this.quizTimeSeconds % 60;
      if (timerEl) {
        timerEl.innerText = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
      }
    }, 1000);
  },

  renderQuiz() {
    const container = document.getElementById('quiz-questions-view');
    if (!container) return;

    if (!this.quizQuestions.length) {
      container.innerHTML = '<div style="text-align: center; padding: 40px;">No practice questions found for this topic yet.</div>';
      return;
    }

    container.innerHTML = `
      <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: var(--radius); padding: 20px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <h3 style="font-size: 17px; font-weight: 700;">Timed Placement Mock Test</h3>
          <div style="font-size: 13px; color: var(--text-secondary);">Category: ${this.currentCategory} • Total Questions: ${this.quizQuestions.length}</div>
        </div>
        <div style="display: flex; align-items: center; gap: 8px; background: var(--bg-primary); padding: 8px 16px; border-radius: 8px; border: 1px solid var(--border-color);">
          <span>⏱️ Time Remaining:</span>
          <span id="quiz-timer" style="font-weight: 700; color: var(--accent-amber); font-family: monospace; font-size: 16px;">10:00</span>
        </div>
      </div>

      <form id="quiz-form" onsubmit="PrepModule.handleQuizSubmit(event)">
        ${this.quizQuestions.map((q, idx) => `
          <div class="card" style="margin-bottom: 18px; padding: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
              <span class="badge badge-blue">Question ${idx + 1} of ${this.quizQuestions.length}</span>
              <span class="badge diff-${q.difficulty.toLowerCase()}">${q.difficulty}</span>
            </div>
            <div style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 16px; line-height: 1.5;">
              ${q.question}
            </div>
            <div style="display: grid; gap: 10px;">
              ${q.options.map((opt, optIdx) => `
                <label style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg-primary); cursor: pointer; transition: all 0.15s;" class="quiz-option-label">
                  <input type="radio" name="question_${q.id}" value="${optIdx}" onchange="PrepModule.selectAnswer(${q.id}, ${optIdx})" style="cursor: pointer;">
                  <span style="font-size: 14px; color: var(--text-primary);">${opt}</span>
                </label>
              `).join('')}
            </div>
          </div>
        `).join('')}

        <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
          <button type="button" onclick="PrepModule.startQuiz()" class="btn btn-secondary">Reset Test</button>
          <button type="submit" class="btn btn-primary" style="padding: 12px 28px; font-size: 15px;">Submit Test & View Solutions</button>
        </div>
      </form>
    `;
  },

  selectAnswer(questionId, optionIndex) {
    this.quizAnswers[questionId] = optionIndex;
  },

  handleQuizSubmit(e) {
    e.preventDefault();
    this.submitQuiz();
  },

  async submitQuiz() {
    if (this.quizTimerInterval) clearInterval(this.quizTimerInterval);

    const answeredCount = Object.keys(this.quizAnswers).length;
    if (answeredCount === 0) {
      showToast('Please answer at least one question before submitting.', 'error');
      return;
    }

    try {
      const res = await fetch('/api/prep/quiz/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answers: this.quizAnswers })
      });
      const data = await res.json();
      this.renderResults(data);
    } catch (err) {
      console.error(err);
      showToast('Error scoring test', 'error');
    }
  },

  renderResults(data) {
    const container = document.getElementById('quiz-questions-view');
    const resultView = document.getElementById('quiz-results-view');
    if (!resultView) return;

    container.style.display = 'none';
    resultView.style.display = 'block';

    const scoreColor = data.percentage >= 70 ? 'var(--accent-emerald)' : (data.percentage >= 40 ? 'var(--accent-amber)' : 'var(--accent-rose)');

    resultView.innerHTML = `
      <div class="card" style="text-align: center; padding: 36px 20px; margin-bottom: 24px; border: 2px solid ${scoreColor};">
        <h2 style="font-size: 24px; font-weight: 800; margin-bottom: 8px;">Test Performance Report</h2>
        <p style="color: var(--text-secondary); font-size: 14px; margin-bottom: 20px;">Detailed analysis of your practice session</p>

        <div style="display: inline-flex; flex-direction: column; align-items: center; justify-content: center; width: 140px; height: 140px; border-radius: 50%; border: 6px solid ${scoreColor}; margin-bottom: 20px;">
          <span style="font-size: 32px; font-weight: 800; color: ${scoreColor};">${data.percentage}%</span>
          <span style="font-size: 12px; color: var(--text-muted); font-weight: 600;">Accuracy</span>
        </div>

        <div style="display: flex; justify-content: center; gap: 32px; font-size: 14px;">
          <div><span style="font-weight: 700; color: var(--accent-emerald); font-size: 18px;">${data.correct}</span> Correct</div>
          <div><span style="font-weight: 700; color: var(--accent-rose); font-size: 18px;">${data.total - data.correct}</span> Incorrect</div>
          <div><span style="font-weight: 700; color: var(--text-primary); font-size: 18px;">${data.total}</span> Attempted</div>
        </div>

        <div style="margin-top: 24px;">
          <button onclick="PrepModule.startQuiz()" class="btn btn-primary">Take Another Mock Test</button>
        </div>
      </div>

      <h3 style="font-size: 18px; font-weight: 700; margin-bottom: 16px;">Question-by-Question Detailed Solutions</h3>
      <div style="display: grid; gap: 16px;">
        ${data.results.map((r, i) => `
          <div class="card" style="border-left: 4px solid ${r.is_correct ? 'var(--accent-emerald)' : 'var(--accent-rose)'};">
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
              <span style="font-weight: 700; font-size: 14px;">Question ${i + 1}</span>
              <span class="badge ${r.is_correct ? 'badge-green' : 'badge-rose'}">
                ${r.is_correct ? '✓ Correct' : '✗ Incorrect'}
              </span>
            </div>
            <div style="font-size: 15px; font-weight: 600; margin-bottom: 14px;">${r.question}</div>
            
            <div style="display: grid; gap: 8px; margin-bottom: 14px;">
              ${r.options.map((opt, optI) => {
                let borderStyle = 'border: 1px solid var(--border-color); background: var(--bg-primary);';
                let tag = '';
                if (optI === r.correct_index) {
                  borderStyle = 'border: 1px solid var(--accent-emerald); background: rgba(16, 185, 129, 0.15); font-weight: 600;';
                  tag = ' <span style="color: #34d399; font-size: 12px; margin-left: 8px;">(Correct Answer)</span>';
                } else if (optI === r.selected_index && !r.is_correct) {
                  borderStyle = 'border: 1px solid var(--accent-rose); background: rgba(244, 63, 94, 0.15);';
                  tag = ' <span style="color: #fb7185; font-size: 12px; margin-left: 8px;">(Your Answer)</span>';
                }
                return `
                  <div style="padding: 10px 14px; border-radius: 8px; font-size: 13px; ${borderStyle}">
                    ${opt} ${tag}
                  </div>
                `;
              }).join('')}
            </div>

            <div style="background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 8px; padding: 12px 16px;">
              <div style="font-size: 12px; font-weight: 700; color: #60a5fa; margin-bottom: 4px;">📖 Explanation:</div>
              <div style="font-size: 13px; color: var(--text-secondary); line-height: 1.5;">${r.explanation}</div>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  }
};
