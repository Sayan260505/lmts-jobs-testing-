﻿// Dedicated DSA Sheet Module
const DSAModule = {
  problems: [],
  topicsSummary: [],
  currentProblem: null,
  activeLanguage: 'python',

  async init() {
    this.bindEvents();
    await this.loadSheet();
  },

  bindEvents() {
    const searchInput = document.getElementById('dsa-search-input');
    const topicSelect = document.getElementById('dsa-topic-filter');
    const diffSelect = document.getElementById('dsa-diff-filter');
    const statusSelect = document.getElementById('dsa-status-filter');

    if (searchInput) {
      searchInput.addEventListener('input', debounce(() => this.loadSheet(), 300));
    }
    if (topicSelect) {
      topicSelect.addEventListener('change', () => this.loadSheet());
    }
    if (diffSelect) {
      diffSelect.addEventListener('change', () => this.loadSheet());
    }
    if (statusSelect) {
      statusSelect.addEventListener('change', () => this.loadSheet());
    }
  },

  async loadSheet() {
    const search = document.getElementById('dsa-search-input')?.value || '';
    const topic = document.getElementById('dsa-topic-filter')?.value || '';
    const diff = document.getElementById('dsa-diff-filter')?.value || '';
    const status = document.getElementById('dsa-status-filter')?.value || '';

    const container = document.getElementById('dsa-problems-list');
    if (!container) return;
    container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-secondary);">Loading DSA problem sheet...</div>';

    try {
      const res = await fetch(`/api/dsa/sheet?search=${encodeURIComponent(search)}&topic=${encodeURIComponent(topic)}&difficulty=${encodeURIComponent(diff)}&status=${encodeURIComponent(status)}`);
      const data = await res.json();
      this.problems = data.problems;
      this.topicsSummary = data.topics_summary;

      this.updateProgressSummary();
      this.renderProblems();
    } catch (err) {
      console.error(err);
      container.innerHTML = '<div style="color: var(--accent-rose); text-align: center; padding: 40px;">Failed to load DSA sheet.</div>';
    }
  },

  updateProgressSummary() {
    let total = this.problems.length;
    let solved = 0;
    let easySolved = 0, medSolved = 0, hardSolved = 0;

    this.problems.forEach(p => {
      if (p.user_status === 'solved') {
        solved++;
        if (p.difficulty === 'Easy') easySolved++;
        if (p.difficulty === 'Medium') medSolved++;
        if (p.difficulty === 'Hard') hardSolved++;
      }
    });

    const percent = total > 0 ? Math.round((solved / total) * 100) : 0;
    const bar = document.getElementById('dsa-progress-bar');
    const text = document.getElementById('dsa-progress-text');
    const badgesEl = document.getElementById('dsa-difficulty-counts');

    if (bar) bar.style.width = `${percent}%`;
    if (text) text.innerText = `${solved}/${total} Completed (${percent}%)`;
    if (badgesEl) {
      badgesEl.innerHTML = `
        <span class="badge diff-easy">Easy: ${easySolved}</span>
        <span class="badge diff-medium">Med: ${medSolved}</span>
        <span class="badge diff-hard">Hard: ${hardSolved}</span>
      `;
    }
  },

  renderProblems() {
    const container = document.getElementById('dsa-problems-list');
    if (!container) return;

    if (!this.problems.length) {
      container.innerHTML = `
        <div style="text-align: center; padding: 50px 20px; background: var(--bg-card); border-radius: var(--radius); border: 1px dashed var(--border-color);">
          <div style="font-size: 32px; margin-bottom: 8px;">📚</div>
          <h4 style="font-size: 16px; margin-bottom: 4px;">No problems found</h4>
          <p style="color: var(--text-secondary); font-size: 13px;">Try relaxing your topic or difficulty filters.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div style="overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse; font-size: 14px; text-align: left;">
          <thead>
            <tr style="border-bottom: 2px solid var(--border-color); color: var(--text-muted); font-size: 12px; text-transform: uppercase;">
              <th style="padding: 12px 14px; width: 140px;">Status</th>
              <th style="padding: 12px 14px;">Problem Title</th>
              <th style="padding: 12px 14px; width: 150px;">Topic</th>
              <th style="padding: 12px 14px; width: 100px;">Difficulty</th>
              <th style="padding: 12px 14px; width: 120px;">Complexity</th>
              <th style="padding: 12px 14px; width: 140px; text-align: right;">Action</th>
            </tr>
          </thead>
          <tbody>
            ${this.problems.map(p => {
              const statusClass = {
                'solved': 'status-solved',
                'in_progress': 'status-progress',
                'review': 'status-review',
                'unsolved': 'status-unsolved'
              }[p.user_status] || '';

              return `
                <tr class="dsa-row fade-in" style="border-bottom: 1px solid var(--border-color); transition: background 0.15s;">
                  <td style="padding: 12px 14px;">
                    <select onchange="DSAModule.updateStatus(${p.id}, this.value)" class="select-filter" style="padding: 4px 8px; font-size: 12px; border-radius: 6px;">
                      <option value="unsolved" ${p.user_status === 'unsolved' ? 'selected' : ''}>○ Todo</option>
                      <option value="in_progress" ${p.user_status === 'in_progress' ? 'selected' : ''}>◐ Doing</option>
                      <option value="solved" ${p.user_status === 'solved' ? 'selected' : ''}>✓ Solved</option>
                      <option value="review" ${p.user_status === 'review' ? 'selected' : ''}>★ Review</option>
                    </select>
                  </td>
                  <td style="padding: 12px 14px;">
                    <div style="font-weight: 600; color: var(--text-primary); margin-bottom: 2px;">
                      ${p.title}
                      ${p.user_notes ? '<span title="Has personal notes" style="font-size: 12px; margin-left: 6px;">📝</span>' : ''}
                    </div>
                    <div style="font-size: 12px; display: flex; gap: 8px;">
                      ${p.leetcode_url ? `<a href="${p.leetcode_url}" target="_blank" style="color: #60a5fa; text-decoration: none;">LeetCode ↗</a>` : ''}
                      ${p.gfg_url ? `<a href="${p.gfg_url}" target="_blank" style="color: #34d399; text-decoration: none;">GFG ↗</a>` : ''}
                    </div>
                  </td>
                  <td style="padding: 12px 14px;">
                    <span class="badge badge-blue" style="font-size: 11px;">${p.topic}</span>
                    <div style="font-size: 11px; color: var(--text-muted); margin-top: 3px;">${p.subtopic || ''}</div>
                  </td>
                  <td style="padding: 12px 14px;">
                    <span class="badge diff-${p.difficulty.toLowerCase()}">${p.difficulty}</span>
                  </td>
                  <td style="padding: 12px 14px; font-size: 12px; color: var(--text-muted); font-family: monospace;">
                    <div>${p.time_complexity}</div>
                    <div>${p.space_complexity}</div>
                  </td>
                  <td style="padding: 12px 14px; text-align: right;">
                    <button onclick="DSAModule.openSolutionModal(${p.id})" class="btn btn-secondary btn-sm" style="padding: 5px 10px;">
                      Code & Notes
                    </button>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `;
  },

  async updateStatus(problemId, newStatus) {
    try {
      const res = await fetch('/api/dsa/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ problem_id: problemId, status: newStatus })
      });
      if (res.ok) {
        showToast('Problem progress updated!', 'success');
        const prob = this.problems.find(p => p.id === problemId);
        if (prob) prob.user_status = newStatus;
        this.updateProgressSummary();
        if (window.App) window.App.updateStats();
      }
    } catch (err) {
      console.error(err);
      showToast('Failed to update status', 'error');
    }
  },

  openSolutionModal(problemId) {
    const prob = this.problems.find(p => p.id === problemId);
    if (!prob) return;
    this.currentProblem = prob;

    const modal = document.getElementById('dsa-solution-modal');
    const titleEl = document.getElementById('solution-modal-title');
    const subtitleEl = document.getElementById('solution-modal-subtitle');
    const intuitionEl = document.getElementById('solution-intuition');
    const timeEl = document.getElementById('solution-time-complexity');
    const spaceEl = document.getElementById('solution-space-complexity');
    const notesEl = document.getElementById('solution-user-notes');

    titleEl.innerText = prob.title;
    subtitleEl.innerHTML = `<span class="badge diff-${prob.difficulty.toLowerCase()}">${prob.difficulty}</span> <span class="badge badge-blue">${prob.topic}</span>`;
    intuitionEl.innerText = prob.intuition;
    timeEl.innerText = `Time Complexity: ${prob.time_complexity}`;
    spaceEl.innerText = `Space Complexity: ${prob.space_complexity}`;
    if (notesEl) notesEl.value = prob.user_notes || '';

    this.switchLanguage(this.activeLanguage);
    modal.classList.add('active');
  },

  switchLanguage(lang) {
    this.activeLanguage = lang;
    document.querySelectorAll('.code-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.lang === lang);
    });

    const codeEl = document.getElementById('solution-code-block');
    if (!codeEl || !this.currentProblem) return;

    let code = '';
    if (lang === 'python') code = this.currentProblem.python_code;
    else if (lang === 'cpp') code = this.currentProblem.cpp_code;
    else if (lang === 'java') code = this.currentProblem.java_code;
    else if (lang === 'js') code = this.currentProblem.js_code;

    codeEl.innerText = code;
  },

  copyCurrentCode() {
    const codeEl = document.getElementById('solution-code-block');
    if (!codeEl) return;
    navigator.clipboard.writeText(codeEl.innerText).then(() => {
      showToast('Code copied to clipboard!', 'success');
    }).catch(() => {
      showToast('Failed to copy', 'error');
    });
  },

  async saveNotes() {
    if (!this.currentProblem) return;
    const notes = document.getElementById('solution-user-notes').value;

    try {
      const res = await fetch('/api/dsa/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          problem_id: this.currentProblem.id,
          status: this.currentProblem.user_status,
          notes: notes
        })
      });
      if (res.ok) {
        this.currentProblem.user_notes = notes;
        showToast('Personal notes saved!', 'success');
        this.renderProblems();
      }
    } catch (err) {
      console.error(err);
      showToast('Failed to save notes', 'error');
    }
  }
};
